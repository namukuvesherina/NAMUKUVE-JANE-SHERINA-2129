folder = fullfile(getenv('USERPROFILE'), 'Desktop', 'Leaves');
files = dir(fullfile(folder, '*.jpg'));
leafNames = {'Cassava','Jackfruit','Guava','Eucalyptus','Mango','Gnut','Blackjack','Avocado','Banana'};
for k = 1:length(files)
    image = imread(fullfile(folder, files(k).name));
    gray = rgb2gray(image);
    bw = imbinarize(gray);
    ed = edge(gray, 'Canny');
    st = regionprops(bw, 'Area', 'Perimeter');

    leaves(k).name = leafNames{k};
    leaves(k).filename = files(k).name;
    leaves(k).original = image;
    leaves(k).gray = gray;
    leaves(k). bw = bw;
    leaves(k). edge = ed;
    leaves(k).area = st(1).Area;
    leaves(k).perimeter = st(1).Perimeter;
end



