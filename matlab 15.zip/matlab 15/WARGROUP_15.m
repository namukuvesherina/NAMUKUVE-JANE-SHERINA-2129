figure;
bar(studentdata.AGE);
xlabel("NAME");
ylabel("AGE");
title("AGE by NAME");
save("WARGROUP_15.mat");

figure;
bar(studentdata.CGPA);
xlabel("NAME");
ylabel("CGPA");
title("CGPA by NAME");
save("WARGROUPPERFORMANCE_15.mat");




