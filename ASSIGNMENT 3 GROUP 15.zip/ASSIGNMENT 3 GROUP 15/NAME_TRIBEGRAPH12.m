x= GROUPWORKEXCEL.TRIBE;
figure;
histogram(x);
xlabel('TRIBE');
ylabel('Number of Students');
title('TRIBE DISTRIBUTION');
xtickangle(45);

