x= GROUPWORKEXCEL.AGE;
figure;
histogram(x);
xlabel('AGE');
ylabel('Number of Students');
title('AGE DISTRIBUTION GRAPH');
