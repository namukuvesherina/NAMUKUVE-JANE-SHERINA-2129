tribeCounts= countcats(GROUPWORKEXCEL.TRIBE);
figure;
pie(tribeCounts);
legend(categories(GROUPWORKEXCEL.TRIBE));
title('Tribe Distribution Pie Chart');
    