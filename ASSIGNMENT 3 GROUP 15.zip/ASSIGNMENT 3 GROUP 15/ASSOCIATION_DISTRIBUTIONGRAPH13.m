x= GROUPWORKEXCEL.ASSOCIATION;
figure;
histogram(x);
xlabel('ASSOCIATION');
ylabel('Number of Students');
title('ASSOCIATION DISTRIBUTION');



