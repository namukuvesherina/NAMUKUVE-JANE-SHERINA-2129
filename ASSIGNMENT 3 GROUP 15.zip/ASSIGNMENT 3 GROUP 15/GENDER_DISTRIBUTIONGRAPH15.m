x= GROUPWORKEXCEL.GENDER;
figure;
histogram(x);
xlabel('GENDER');
ylabel('Number of Students');
title('GENDER DISTRIBUTION');

