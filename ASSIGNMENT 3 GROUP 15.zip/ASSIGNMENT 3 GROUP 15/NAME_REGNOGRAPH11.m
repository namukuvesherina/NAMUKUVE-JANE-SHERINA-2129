x= GROUPWORKEXCEL.NAME;
y= GROUPWORKEXCEL.REGNO;
bar(1:length(x));
xticks(1:length(x));
xticklabels(x);
xtickangle(90);
xlabel('NAME');
ylabel('REGNO');
title('NAME vs REGNOGRAPH');
for i= 1:length(x)
    text(i, i+0.5, y(i), 'Rotation', 90,'FontSize',6,HorizontalAlignment='left');
end

