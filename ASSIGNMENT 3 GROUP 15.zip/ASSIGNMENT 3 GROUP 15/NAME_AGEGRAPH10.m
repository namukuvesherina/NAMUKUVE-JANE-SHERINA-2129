x= GROUPWORKEXCEL.NAME;
y= GROUPWORKEXCEL.AGE;
bar(y);
xticks(1:length(x));
xticklabels(x);
xtickangle(90);
xlabel('NAME');
ylabel('AGE');
title('NAME vs AGE - BAR GRAPH');

