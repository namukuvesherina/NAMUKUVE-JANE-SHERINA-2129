x= GROUPWORKEXCEL.HOSTELHALL;
figure;
histogram(x);
xlabel('HOSTELHALL');
ylabel('Number of Students');
title('HOSTEL AND HALL DISTRIBUTION');



    
