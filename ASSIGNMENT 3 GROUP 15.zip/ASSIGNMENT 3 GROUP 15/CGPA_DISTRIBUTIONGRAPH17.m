x= GROUPWORKEXCEL.CGPA;
figure;
histogram(x);
xlabel('CGPA');
ylabel('Number of Students');
title('CGPA DISTRIBUTION GRAPH');
