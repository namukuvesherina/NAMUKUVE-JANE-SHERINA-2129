figure;
scatter(1:length(GROUPWORKEXCEL.NAME), GROUPWORKEXCEL.AGE, 50,'filled');
xticks(1:length(GROUPWORKEXCEL.NAME));
xticklabels(GROUPWORKEXCEL.NAME);
xtickangle(90);
xlabel('NAME');
ylabel('AGE');
title('A Scatter Plot of Name vs Age');
