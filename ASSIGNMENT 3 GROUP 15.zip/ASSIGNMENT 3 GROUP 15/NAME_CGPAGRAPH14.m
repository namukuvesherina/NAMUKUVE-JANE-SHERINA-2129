x=GROUPWORKEXCEL.NAME;
y= GROUPWORKEXCEL.CGPA;
bar(y);
xticks(1:length(x));
xticklabels(x);
xtickangle(90);
xlabel('NAME');
ylabel('CGPA');
title('NAME vs CGPA GRAPH');
